module.exports = {
    DB_URI: 'mongodb://localhost:27017/chocoroom',
    PORT: 5000
}