const express = require('express');
const exphbs = require('express-handlebars');
const path = require('path');
const errorHandler = require('./middleware/error');
const helmet = require('helmet');
const mongoose = require('mongoose');
const {DB_URI, PORT} = require('./keys');
const orders = require('./routes/orders');
const session = require('express-session');
var bodyParser = require('body-parser');
const Order = require('./models/orders');

const app = express();
const port = PORT || 5000;

const hbs = exphbs.create({
    defaultLayout: 'main',
    extname: 'hbs',
});

app.engine('hbs', hbs.engine);
app.set('view engine', 'hbs');
app.set('views', 'views');

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));


app.use(session({
    secret: "aeb74192-962c-11ed-a1eb-0242ac120002",
    saveUninitialized: true,
    resave: false
}));
app.use((req, res, next) => {
    res.locals.message = req.session.message;
    delete req.session.message;
    next();
});

app.use(helmet.dnsPrefetchControl());
app.use(helmet.expectCt());
app.use(helmet.frameguard());
app.use(helmet.hidePoweredBy());
app.use(helmet.hsts());
app.use(helmet.ieNoOpen());
app.use(helmet.noSniff());
app.use(helmet.permittedCrossDomainPolicies());
app.use(helmet.referrerPolicy());
app.use(helmet.xssFilter());


app.get('/', (req, res) => {
    Order.find().sort("-id").limit(1).exec((err, val) => {
        if(err){
            res.json({ message: err.message });
        } else {
            res.render('index', {title: 'ChocoRoom', maxCount:val[0].id})
        }
    });
});

app.use('/orders', orders);
app.use(errorHandler);

mongoose.set("strictQuery", false);
mongoose.connect(DB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('MongoDBga ulanish hosil qilindi...');
    app.listen(port, () => {
        console.log(`Server started on port ${port}`);
    })
  })
  .catch((err) => {
    console.error('MongoDBga ulanish vaqtida xato ro\'y berdi...', err);
  });
