const mongoose = require('mongoose');


const today = new Date();
const yyyy = today.getFullYear();
let mm = today.getMonth() + 1; // Months start at 0!
let dd = today.getDate();

if (dd < 10) dd = '0' + dd;
if (mm < 10) mm = '0' + mm;

const formattedToday = dd + '.' + mm + '.' + yyyy;

const orderSchema = new mongoose.Schema({
    id: {
        type: Number,
        required: true,
        unique : true
    },
    name: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    created: {
        type: String,
        required: true,
        default: formattedToday 
    }
})

module.exports = mongoose.model('orders', orderSchema)