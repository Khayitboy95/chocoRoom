const router = require('express').Router();
const Order = require('./../models/orders');

router.get('/', (req, res) => {
    Order.find((err, orders) => {
        if(err){
            res.json({ message: err.message });
        } else {
            res.render('orders', {title: 'Buyurtmalar', orders})
        }
    }).lean();
});

router.get('/add', (req, res) => {
    res.render('add', {title: 'Buyurtma qo\'shish'})
});

router.post('/add', (req, res) => {
    const order = new Order({
        id: req.body.id,
        name: req.body.name,
        phone: req.body.phone
    });
    order.save((err) => {
        if(err) {
            res.json({ message: err.message, type: 'danger' });
        } else {
            req.session.message = {
                type: 'success',
                message: 'Buyurtma muvaffaqiyatli qo\'shildi!'
            }
            res.redirect('/orders');
        }
    })
});

router.get('/edit/:id', (req, res) => {
    const id = req.params.id;
    Order.findById(id, (err, order) => {
        if(err) {
            res.redirect('/');
        } else {
            if(order == null) {
                res.redirect('/');    
            } else {
                res.render('edit', {
                    title: "Buyurtmani o'zgartirish",
                    order
                });
            }
        }
    }).lean();
});

router.post('/update/:id', (req, res) => {
    const id = req.params.id;
    Order.findByIdAndUpdate(id, {
        id: req.body.id,
        name: req.body.name,
        phone: req.body.phone
    }, (err, result) => {
        if(err) {
            res.json({ message: err.message, type: 'danger' });
        } else {
            req.session.message = {
                type: 'success',
                message: 'Buyurtma muvaffaqiyatli o\'zgartirildi!'
            }
            res.redirect('/orders');
        }
    })
});

router.get('/delete/:id', (req, res) => {
    const id = req.params.id;
    Order.findByIdAndRemove(id, (err, result) => {
        if(err) {
            res.json({ message: err.message });
        } else {
            req.session.message = {
                type: 'info',
                message: 'Buyurtma muvaffaqiyatli o\'chirildi!'
            }
            res.redirect('/orders');
        }
    }) 
})


router.get('/:id', (req, res) => {
    const id = req.params.id;
    Order.find({"id" :  id}, (err, order) => {
        if(err) {
            res.redirect('/');
        } else {
            if(order == null) {
                res.redirect('/');    
            } else {
                res.json(order[0]);
            }
        }
    }).lean();
});


module.exports = router;